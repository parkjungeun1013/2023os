#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

int main(){
	char *argv[2];
	argv[0] = "ls"; 
	argv[1] = 0; 

	int pid = fork();
	if (pid>0){
		printf("parent: child =%d\n", pid);
		pid = wait(NULL);
		printf("child %d is done\n", pid);
	}
	else if (pid ==0){
		printf("child: exiting\n");
		execve("/bin/ls",argv,NULL);
	}
	else
		printf("fork error\n");
	return 0;
}
